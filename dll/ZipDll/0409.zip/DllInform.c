#include <windows.h>
#include "Zip.h"
#pragma hdrstop

//#include "ZipErr.h"
/* DLLInform.c
 * Copyright (C) 1997 Mike White , Eric W. Engler and Russell Peters
 * Permission is granted to any individual or institution to use, copy, or
 * redistribute this software so long as all of the original files are included,
 * that it is not sold for profit, and that this copyright notice is retained.
  ** distributed under LGPL license ** see license.txt for details
*/
//#include <windows.h>
//#include "Zip.h"
//#include "Globals.h"
static const char *errs[4] = { "", " ", "trace: ", "Trace: " };

int __cdecl
Inform( struct Globals *pG, int err, int type, const char *format, ... )
{
  va_list argptr;
  char    buf[513];
  char    *buffer = buf;
  int     blen = 512;

  if ( !pG )
    pG = ( struct Globals * )GlobalPointer; // GetGlobalPointer (
                                                ///&
                                                ///Error );
  if ( !pG )
    return -1;  // should not happen
  buf[0] = 0;
  if ( type != IWARNING && type <= ITRACE )
  {
    lstrcpy( buf, errs[type] );
    blen = lstrlen( buf );
    buffer = buf + blen;
    blen = 512 - blen;
  }

  va_start( argptr, format );
  vsnprintf( buffer, blen, format, argptr );
  buf[512] = 0;

  // warning message, or info message only
  user_callback( 4, err, 0, buf, pG );
  va_end( argptr );

  return 0;
}
